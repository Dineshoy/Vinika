package com.cg.rms.UI;

import java.util.Scanner;

import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CourseService;
import com.cg.rms.service.CourseServiceImpl;

public class CompanyUI {
	
	public void companyUimethod() throws RecruitmentException{
		CourseService cser = new CourseServiceImpl();
		
String role="company";
		
		Scanner sc = new Scanner(System.in);
		System.out.println("********Company Login Page*********");
		System.out.println();
		System.out.println();
		System.out.println("Enter your login id:");
		String username=sc.next();
		System.out.println("Enter your password:");
		String password=sc.next();
		

		
		try {
			int value=cser.login(username, password, role);
			
			if(value == 2)
			{
				System.out.println("Wrong Credentials.Please try again");
			}
			if(value==1)
			{
				
				System.out.println("welcome Company");
			}
		}
			
			catch (RecruitmentException e)
			{
				throw new RecruitmentException("Wrong credentials.Please retry.");
			}
		
		

		do {
			System.out.println("Menu");
			System.out.println("1. Insert company details");
			System.out.println("2. update company details");
			
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1:
			try{
				System.out.println("Enter Company Name :");
				String company_name = sc.next();
				System.out.println("Enter company Address :");
				String company_address = sc.next();
				System.out.println("Enter contact person :");
				String contact_person = sc.next();
				System.out.println("Enter email id");
				String email_id = sc.next();
				System.out.println("Enter contact number");
				String contact_number = sc.next();
				
				CompanyMaster cmaster = new CompanyMaster();
				cmaster.setCompany_name(company_name);
				cmaster.setCompany_address(company_address);
				cmaster.setContact_person(contact_person);
				cmaster.setEmail_id(email_id);
				cmaster.setContact_number(contact_number);
				String comp_id=cser.addCompanyDetails(cmaster);
				System.out.println("Successfully registered with registration id :"+comp_id);
			}catch(RecruitmentException e1){
				e1.printStackTrace();
			}
				
				break;
				
			case 2:
				try {
					boolean b = cser.updateCompanyDetails();
					if(b) {
						System.out.println("Details updated s");
					}
				} catch (RecruitmentException e1) {
					e1.printStackTrace();
				
				break;

			}

			}
		}while(true);
	
		}
	}
	
